#
# ISC License
#
# Copyright (c) 2026, Autonomous Vehicle Systems Lab, University of Colorado at Boulder
#
# Permission to use, copy, modify, and/or distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#

buildInfoData = {
    "schemaVersion": 4,
    "artifact": {
        "basiliskVersion": "2.13.0b0",
        "sourceRevision": "f78c2978213ee3eaffde0146877df9755fc62f1f",
        "sourceDirty": False,
        "extensionAbiVersion": 3,
    },
    "features": {
        "vizInterface": True,
        "opNav": False,
        "mujoco": True,
        "rustModules": True,
    },
    "diagnostics": {
        "target": {
            "system": "Linux",
            "processor": "x86_64",
            "pointerSizeBytes": 8,
            "osxArchitectures": "",
            "osxDeploymentTarget": "",
        },
        "build": {
            "configuration": "Release",
            "multiConfig": False,
            "availableConfigurations": [],
            "generator": "Ninja",
            "generatorPlatform": "",
            "generatorToolset": "",
            "pythonLimitedApi": "0x03090000",
        },
        "compilers": {
            "c": {
                "id": "GNU",
                "version": "14.2.1",
                "executable": "cc",
                "launcher": "sccache",
                "frontendVariant": "GNU",
                "simulatedId": "",
                "simulatedVersion": "",
                "target": "",
                "standard": "",
                "extensions": "",
            },
            "cxx": {
                "id": "GNU",
                "version": "14.2.1",
                "executable": "c++",
                "launcher": "sccache",
                "frontendVariant": "GNU",
                "simulatedId": "",
                "simulatedVersion": "",
                "target": "",
                "standard": "17",
                "extensions": "OFF",
            },
            "rust": {
                "id": "rustc",
                "version": "1.99.1",
                "executable": "rustc",
                "launcher": "",
                "target": "x86_64-unknown-linux-gnu",
            },
        },
        "conanSettings": {
            "buildType": "Release",
            "cxxStandard": "17",
            "cxxStandardLibrary": "libstdc++11",
            "compilerRuntime": "",
            "compilerRuntimeType": "",
        },
        "tools": {
            "cmake": "4.4.4",
            "conan": "2.33.0",
            "swig": "4.5.1",
            "python": "3.9.25",
            "cargo": "1.99.1",
            "corrosion": "0.6.1",
        },
    },
}
