#
# ISC License
#
# Copyright (c) 2026, Autonomous Vehicle Systems Lab, University of Colorado at Boulder
#
# Permission to use, copy, modify, and/or distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#

buildInfoData = {
    "schemaVersion": 4,
    "artifact": {
        "basiliskVersion": "2.13.0b0",
        "sourceRevision": "17f8b268a699e9783087ef79534f92aa144d2f42",
        "sourceDirty": False,
        "extensionAbiVersion": 3,
    },
    "features": {
        "vizInterface": True,
        "opNav": False,
        "mujoco": True,
        "rustModules": True,
    },
    "diagnostics": {
        "target": {
            "system": "Windows",
            "processor": "AMD64",
            "pointerSizeBytes": 8,
            "osxArchitectures": "",
            "osxDeploymentTarget": "",
        },
        "build": {
            "configuration": "Release",
            "multiConfig": False,
            "availableConfigurations": [],
            "generator": "Ninja",
            "generatorPlatform": "",
            "generatorToolset": "",
            "pythonLimitedApi": "0x03090000",
        },
        "compilers": {
            "c": {
                "id": "MSVC",
                "version": "19.51.36260.0",
                "executable": "cl.exe",
                "launcher": "sccache",
                "frontendVariant": "MSVC",
                "simulatedId": "",
                "simulatedVersion": "",
                "target": "",
                "standard": "",
                "extensions": "",
            },
            "cxx": {
                "id": "MSVC",
                "version": "19.51.36260.0",
                "executable": "cl.exe",
                "launcher": "sccache",
                "frontendVariant": "MSVC",
                "simulatedId": "",
                "simulatedVersion": "",
                "target": "",
                "standard": "17",
                "extensions": "OFF",
            },
            "rust": {
                "id": "rustc",
                "version": "1.99.1",
                "executable": "rustc.exe",
                "launcher": "",
                "target": "x86_64-pc-windows-msvc",
            },
        },
        "conanSettings": {
            "buildType": "Release",
            "cxxStandard": "17",
            "cxxStandardLibrary": "",
            "compilerRuntime": "dynamic",
            "compilerRuntimeType": "Release",
        },
        "tools": {
            "cmake": "4.4.4",
            "conan": "2.33.0",
            "swig": "4.5.1",
            "python": "3.9.13",
            "cargo": "1.99.1",
            "corrosion": "0.6.1",
        },
    },
}
