function changeInputs(energy,localtime,kpindex)
%% changeInputs
% Function to change the input parameters for the Denton model Fortran code

% Modify energy in flux_model.f file
replacestring('flux_model0.f','flux_model.f','choose_en=ENERGY',['choose_en=',num2str(energy)])

% Modify local time in flux_model.f file
replacestring('flux_model.f','flux_model.f','choose_lt=LOCALTIME',['choose_lt=',num2str(localtime)])

% Modify Kp index in flux_model.f file
replacestring('flux_model.f','flux_model.f','choose_kp=KPINDEX',['choose_kp=',num2str(kpindex)])

end