function replacestring(input,output,org_string,rep_string)
% Replaces the string org_string from the input file by the new string
% rep_string and writes the result in output.

% Read original file
fid  = fopen(input,'r');
f=fread(fid,'*char')';
fclose(fid);

% Replace string
f = strrep(f,org_string,rep_string);

% Write new file
fid  = fopen(output,'w');
fprintf(fid,'%s',f);
fclose(fid);
end