clear
% Runs a batch of Denton Model flux computations

% Parameters
Energies = [100 6766 13432 20098 26764 33430];
LTs = [0.00, 14.73];
Kps = [1, 22];

eFlux = NaN(length(LTs),length(Energies), length(Kps));
iFlux = NaN(length(LTs),length(Energies), length(Kps));

errors = 0;
for i = 1:length(Kps)
    for j = 1:length(LTs)
        for k = 1:length(Energies)
            fprintf('Running Denton Fortran Model: Kp-Index = %d, LT = %.2f, Energy = %.2feV \n',Kps(i),LTs(j),Energies(k))
            changeInputs(Energies(k),LTs(j),Kps(i))
            [~,~] = system('rm fluxmodel');
            [~,~] = system('make fluxmodel');
            [status,cmdout] = system('./fluxmodel');

            % separate cmd output into lines
            cmdoutLines = split(cmdout,newline);

            % Detect error
            error = contains(cmdout,'Fortran runtime error:') || status ~= 0;
            if error == 1
                ErrorMsg = cmdoutLines{30};
                disp(['ERROR: ', ErrorMsg])
                errors = errors + 1;
                continue;
            end

            % find mean electron flux
            strings = split(cmdoutLines{38},' ');
            strings = strings(~cellfun('isempty',strings));
            % check that this is the line with MEAN
            if ~strcmp(strings{1},'MEAN')
                disp('ERROR: wrong line for mean electron flux')
            else
                eFluxMean = str2double(strings{2});
                eFlux(j,k,i) = eFluxMean;
            end

            % find mean ion flux
            strings = split(cmdoutLines{48},' ');
            strings = strings(~cellfun('isempty',strings));
            % check that this is the line with MEAN
            if ~strcmp(strings{1},'MEAN')
                disp('ERROR: wrong line for mean ion flux')
            else
                iFluxMean = str2double(strings{2});
                iFlux(j,k,i) = iFluxMean;
            end
        end
        name = ['FluxData_',num2str(Kps(i)),'_',num2str(LTs(j),'%.2f'),'.txt'];
        writematrix([Energies; eFlux(j,:,i); iFlux(j,:,i)],name);
    end
end
fprintf('Completed with %d errors. \n',errors)