#include "customGeneralModule.h"

void printHelloWorld() {
	printf("Hello World\n" );
	return;
}
