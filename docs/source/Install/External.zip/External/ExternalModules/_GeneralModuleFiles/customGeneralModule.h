
#ifndef _CUSTOM_MODULE_MSG_H_
#define _CUSTOM_MODULE_MSG_H_
#include <stdio.h>

#define HMMM 24

#ifdef __cplusplus
extern "C" {
#endif

	void printHelloWorld();

#ifdef __cplusplus
}
#endif


#endif
