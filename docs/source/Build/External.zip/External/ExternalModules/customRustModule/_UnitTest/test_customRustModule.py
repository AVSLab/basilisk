# ISC License
#
# Copyright (c) 2026, Autonomous Vehicle Systems Lab, University of Colorado at Boulder
#
# Permission to use, copy, modify, and/or distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import numpy as np

from Basilisk.ExternalModules import customRustModule
from Basilisk.architecture import messaging
from Basilisk.utilities import SimulationBaseClass, macros


def test_custom_rust_module():
    """Verify an external Rust module reads and writes an external C message."""
    simulation = SimulationBaseClass.SimBaseClass()
    process = simulation.CreateNewProcess("testProcess")
    task_name = "testTask"
    process.addTask(simulation.CreateNewTask(task_name, macros.sec2nano(0.5)))

    module = customRustModule.customRustModule()
    simulation.AddModelToTask(task_name, module)

    input_payload = messaging.CustomModuleMsgPayload()
    input_payload.dataVector = [1.0, -0.5, 0.7]
    input_message = messaging.CustomModuleMsg().write(input_payload)
    module.dataInMsg.subscribeTo(input_message)

    recorder = module.dataOutMsg.recorder()
    simulation.AddModelToTask(task_name, recorder)

    simulation.InitializeSimulation()
    simulation.ConfigureStopTime(macros.sec2nano(1.0))
    simulation.ExecuteSimulation()

    np.testing.assert_allclose(
        recorder.dataVector,
        [[2.0, -0.5, 0.7], [3.0, -0.5, 0.7], [4.0, -0.5, 0.7]],
        rtol=0.0,
        atol=1e-12,
    )
