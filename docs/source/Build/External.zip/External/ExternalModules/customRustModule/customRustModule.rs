// ISC License
//
// Copyright (c) 2026, Autonomous Vehicle Systems Lab, University of Colorado at Boulder
//
// Permission to use, copy, modify, and/or distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
// ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
// OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

//! Sample Rust module built through Basilisk's integrated external-module path.

#![allow(non_snake_case)]

use bsk_messages::*;

/// Python-visible configuration and message ports.
#[bsk_build::module]
#[repr(C)]
pub struct CustomRustModuleConfig {
    /// [-] Number of update calls since reset
    pub dummy: f64,
    /// [-] Optional external input message
    #[bsk(optional)]
    pub dataInMsg: MsgReader<CustomModuleMsg>,
    /// [-] External output message
    pub dataOutMsg: MsgWriter<CustomModuleMsg>,
}

impl BskModule for CustomRustModuleConfig {
    type State = ();
    type Inputs = CustomRustModuleInputs;
    type Outputs = CustomRustModuleOutputs;

    fn reset(
        &mut self,
        _state: &mut Self::State,
        context: &BskContext<'_>,
        _current_sim_nanos: u64,
    ) -> BskResult<Self::Outputs> {
        self.dummy = 0.0; // [-]
        context.logger().info("External Rust module reset.");
        Ok(CustomRustModuleOutputs {
            dataOutMsg: Some(CustomModuleMsg::default()),
        })
    }

    fn update(
        &mut self,
        _state: &mut Self::State,
        _context: &BskContext<'_>,
        inputs: Self::Inputs,
        _current_sim_nanos: u64,
    ) -> BskResult<Self::Outputs> {
        let mut output = inputs.dataInMsg.unwrap_or_default();
        self.dummy += 1.0; // [-]
        output.dataVector[0] += self.dummy;
        Ok(CustomRustModuleOutputs {
            dataOutMsg: Some(output),
        })
    }
}
