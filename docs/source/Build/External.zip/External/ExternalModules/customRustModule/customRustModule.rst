.. Copyright (c) 2026, Autonomous Vehicle Systems Lab, University of Colorado at Boulder
..
.. SPDX-License-Identifier: ISC

Executive Summary
-----------------

This sample demonstrates a Rust Basilisk module compiled from an integrated
external-module project. It reads and writes the external project's
``CustomModuleMsg`` C message and increments the first vector component on
each update.

Message Connection Descriptions
-------------------------------

.. bsk-module-io:: customRustModule
   :caption: Module I/O Messages
   :module-type: Rust

   input dataInMsg CustomModuleMsgPayload
      (optional) Input data vector. A zero vector is used when unconnected.

   output dataOutMsg CustomModuleMsgPayload
      Input data vector with its first component incremented by the update
      count since reset.

Module Assumptions and Limitations
----------------------------------

This module is a build and messaging example rather than a physical model.

User Guide
----------

Build Basilisk with ``--rustModules True`` and
``--pathToExternalModules /path/to/External``, then import the module with:

.. code-block:: python

   from Basilisk.ExternalModules import customRustModule

   module = customRustModule.customRustModule()
